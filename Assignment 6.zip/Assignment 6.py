import tkinter as tk
from tkinter import messagebox

# Function to evaluate the expression entered
def evaluate_expression():
    try:
        result = eval(entry_field.get())  # Evaluates user input expression
        entry_field.delete(0, tk.END)  # Clears previous input
        entry_field.insert(tk.END, result)  # Displays result
    except ZeroDivisionError:
        messagebox.showerror("Error", "Division by zero is not allowed.")
    except Exception as e:
        messagebox.showerror("Error", f"Invalid input: {e}")

# Function to insert numbers & operators into the entry field
def insert_value(value):
    entry_field.insert(tk.END, value)

# Function to clear the entry field
def clear_field():
    entry_field.delete(0, tk.END)

# Create main application window
root = tk.Tk()
root.title("Tkinter Calculator")
root.geometry("300x400")

# Entry field for input
entry_field = tk.Entry(root, font=("Arial", 16), borderwidth=2, relief="solid", justify="right")
entry_field.grid(row=0, column=0, columnspan=4, ipadx=8, ipady=8)

# Button layout
buttons = [
    ("7", 1, 0), ("8", 1, 1), ("9", 1, 2), ("/", 1, 3),
    ("4", 2, 0), ("5", 2, 1), ("6", 2, 2), ("*", 2, 3),
    ("1", 3, 0), ("2", 3, 1), ("3", 3, 2), ("-", 3, 3),
    ("0", 4, 0), (".", 4, 1), ("=", 4, 2), ("+", 4, 3),
]

# Create buttons dynamically
for (text, row, col) in buttons:
    if text == "=":
        btn = tk.Button(root, text=text, font=("Arial", 16), command=evaluate_expression)
    else:
        btn = tk.Button(root, text=text, font=("Arial", 16), command=lambda val=text: insert_value(val))
    btn.grid(row=row, column=col, ipadx=10, ipady=10, padx=5, pady=5)

# Clear button
clear_btn = tk.Button(root, text="C", font=("Arial", 16), command=clear_field)
clear_btn.grid(row=5, column=0, columnspan=4, ipadx=85, ipady=10, padx=5, pady=5)

# Run the Tkinter event loop
root.mainloop()
